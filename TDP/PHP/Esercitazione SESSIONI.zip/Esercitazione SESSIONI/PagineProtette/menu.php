<?php
session_start();
echo "BENVENUTO nel nostro SPLENDIDO SITO<br><br>";
echo "1 - <a href=pagina1.php>Pagina 1</a><br>";
echo "2 - <a href=pagina2.php>Pagina 2</a><br>";
echo "3 - <a href=pagina3.php>Pagina 3</a><br><br>";
echo "X - <a href=../index.html>ESCI DAL SITO</a>";
?>