<?php
echo "Salve!<br>Le credenziali inserite sono corrette! Questa e' la pagina riservata";
?>